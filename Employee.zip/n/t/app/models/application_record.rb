class ApplicationRecord < ActiveRecord::Base
  primary_abstract_class
end

class Worker < ApplicationRecord

end